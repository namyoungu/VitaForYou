package com.example.vita_1.adapter;

public interface MyEventListener {
    void onEvent(int pos);
    void onLongEvent(int pos);
}