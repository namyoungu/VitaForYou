package com.example.vita_1.CustomListMaker;

public class TextListViewItem {

    private String splName;

    public String getSplName() {
        return splName;
    }

    public void setSplName(String splName) {
        this.splName = splName;
    }
}
